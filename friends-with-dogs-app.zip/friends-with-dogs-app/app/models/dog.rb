class Dog < ApplicationRecord
  belongs_to :owner
end
